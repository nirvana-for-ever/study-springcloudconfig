'use strict';

const Service = require('egg').Service;
const { AppError, ERROR_CODE_MAP } = require('../../error');

class MessageService extends Service {

  async submit({ content, name }) {
    await this.app.model['Message'].create({
      id: this.ctx.helper.getId(),
      content,
      name
    });
  }

  async list() {
    const list = await this.app.model['Message'].findAll({
      attributes: [
        'content',
        'name'
      ],
      raw: true
    });
    return list;
  }
}

module.exports = MessageService;
