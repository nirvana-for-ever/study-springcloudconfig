'use strict';

const Service = require('egg').Service;
const { STATUS_PUBLISH } = require('../../constants/blog');
const { AppError, ERROR_CODE_MAP } = require('../../error');

class BlogService extends Service {
  /**
   * 获取博客详情
   * 有几种情况会使用到：
   * 1. 点击进入文章详情页时
   * 2. 打开自己的草稿/修改已发布文章
   * 情况2 不需要查作者信息，其余逻辑基本一致
   *
   * @param {*} id
   * @param {*} isPublish
   * @param {boolean} isEdit 是否是编辑页的查询，如果是就不需要查作者信息
   * @returns
   */
  async getBlogById(id, isPublish, isEdit) {
    // 对应 model 文件的大驼峰名
    const where = {
      id
    };
    if (isPublish !== null) {
      where.isPublish = isPublish;
    }
    const blog = await this.app.model['Blog'].findOne({
      attributes: [
        'id',
        'authId',
        'blogContentId',
        'readCount',
        'likeCount',
        'commentCount',
        'title',
        'createTime',
        'introduction',
        'img'
      ],
      where,
      raw: true
    });
    if (!blog) {
      throw new AppError(ERROR_CODE_MAP.BLOG_NOT_EXIST);
    }

    const content = await this.ctx.service.blogContent.index.getMd(
      blog.blogContentId
    );

    let authInfo = null;
    if (!isEdit) {
      authInfo = await this.ctx.service.user.index.getUserSimpleInfoById(
        blog.authId
      );
    }

    const tagIds = await this.ctx.model['BlogTag'].findAll({
      attributes: ['tagId'],
      where: {
        blogId: id
      },
      raw: true
    });

    const tags = await this.ctx.service.tag.index.getTagSimpleInfoByIds(
      tagIds?.map(item => item.tagId) || []
    );

    return {
      id: blog.id,
      authId: blog.authId,
      readCount: blog.readCount,
      likeCount: blog.likeCount,
      commentCount: blog.commentCount,
      title: blog.title,
      createTime: blog.createTime,
      introduction: blog.introduction,
      contentMd: content?.contentMd || '',
      highlight: content?.highlight || '',
      img: blog.img,
      tags,
      authInfo
    };
  }

  /**
   * 获取博客列表
   * 1. 首页博客列表
   * 2. 个人页博客集或者草稿箱 // TODO
   * 3. 搜索页查找
   * 4. 个人页热门博客
   * @param {*} param0
   * @returns
   */
  async getBlogList({ query, page, size, isPublish = STATUS_PUBLISH, timeLimit, userId }) {
    const { lte } = this.app.Sequelize.Op;
    let options;
    if (query) {
      // 搜索页查找
      // 先进行分词
      query = query
        .trim()
        .replace(/\s+/g, ' ') // 去除多个空格
        .replace(/([A-Za-z])([\u4e00-\u9fa5]+)/g, '$1 $2') // 中英文之间加空格
        .replace(/([\u4e00-\u9fa5]+)([A-Za-z])/g, '$1 $2') // 中英文之间加空格
        .split(' ');
      const sql = query.reduce((prev, cur, index) => {
        return `${prev}+${cur}${index === query.length - 1 ? '' : ' & '}`;
      }, '');
      options = {
        where: [
          { is_publish: STATUS_PUBLISH },
          { create_time: { [lte]: timeLimit } },
          this.app.Sequelize.literal(
            'MATCH ( title, introduction ) AGAINST (:sql IN BOOLEAN MODE)'
          )
        ],
        order: [
          [
            this.app.Sequelize.literal(
              'MATCH ( title, introduction ) AGAINST (:sql IN BOOLEAN MODE)'
            ),
            'DESC'
          ]
        ],
        replacements: {
          sql
        }
      };
    } else {
      options = {
        where: [{ is_publish: isPublish }],
        order: [['createTime', 'DESC']]
      };
      if (userId) {
        options.where.push({ auth_id: userId });
      }
      if (timeLimit) {
        options.where.push({ create_time: { [lte]: timeLimit } });
      }
    }
    let blogs = await this.app.model['Blog'].findAll({
      attributes: [
        'id',
        'authId',
        'readCount',
        'likeCount',
        'commentCount',
        'title',
        'createTime',
        'introduction',
        'img'
      ],
      raw: true,
      offset: page * size,
      limit: size,
      ...options
    });

    if (query) {
      blogs.forEach(blog => {
        blog.keywords = query;
      });
      return blogs;
    }

    if (!userId) {
      const authIds = Array.from(new Set(blogs.map(blog => blog.authId)));
      const nickNameMap = {};
      const users = await this.ctx.service.user.index.getUserNicknameListByIds(
        authIds
      );
      if (users) {
        users.forEach(user => {
          nickNameMap[user.id] = user.nickName;
        });
      }
      blogs = blogs.map(blog => {
        return {
          ...blog,
          authName: nickNameMap[blog.authId]
        };
      });
    }

    for (let i = 0; i < blogs.length; i++) {
      const blog = blogs[i];
      const tags = await this.ctx.service.blog.index.getTagsByBlogId(blog.id);
      blog.tags = tags;
    }

    return blogs;
  }

  /**
   * 查找标签对应博客列表
   */
  async getBlogListByTag({ page, size, tagId }) {
    const blogs = await this.app.model.query(
      'SELECT mid.*, u.nick_name authName FROM (' +
        'SELECT ' +
        'b.id,b.auth_id authId,b.read_count readCount,b.like_count likeCount,' +
        'b.comment_count commentCount,b.title,b.create_time createTime,b.introduction, b.img ' +
        'FROM blog_tag bt LEFT JOIN blog b on bt.blog_id = b.id ' +
        'WHERE bt.tag_id = :tagId AND b.is_publish = :isPublish ' +
        'ORDER BY b.create_time DESC ' +
        'LIMIT :offset,:limit' +
        ') mid LEFT JOIN user u ON mid.authId = u.id',
      {
        type: this.app.Sequelize.QueryTypes.SELECT,
        replacements: {
          tagId,
          isPublish: STATUS_PUBLISH,
          offset: page * size,
          limit: size
        }
      }
    );

    for (let i = 0; i < blogs.length; i++) {
      const blog = blogs[i];
      const tags = await this.ctx.service.blog.index.getTagsByBlogId(blog.id);
      blog.tags = tags;
    }
    return blogs;
  }

  /**
   * 根据博客查找对应标签信息
   * @param {*} id
   */
  async getTagsByBlogId(id) {
    const tags = await this.app.model.query(
      'SELECT t.id, t.name FROM tag t LEFT JOIN blog_tag bt ON bt.tag_id = t.id WHERE bt.blog_id = :id',
      {
        type: this.app.Sequelize.QueryTypes.SELECT,
        replacements: {
          id
        }
      }
    );
    return tags;
  }

  /**
   * 获取 6 个浏览量最高的博客作为推荐
   */
  async getBlogRecommandList() {
    const blogs = await this.app.model['Blog'].findAll({
      attributes: ['id', 'title'],
      order: [['readCount', 'DESC']],
      offset: 0,
      limit: 6,
      raw: true
    });
    return blogs;
  }

  /**
   * 获取档案博客，所有都查出来
   */
  async getRecordList() {
    const blogs = await this.app.model['Blog'].findAll({
      attributes: ['id', 'title', 'createTime'],
      where: {
        authId: this.app.config.myId
      },
      order: [['createTime', 'DESC']]
    });
    return blogs;
  }

  /**
   * 提交博客
   */
  async submit(data) {
    const { ctx, app } = this;
    const { in: opIn } = app.Sequelize.Op;
    let transaction = null;
    try {
      // 创建事务对象
      transaction = await app.model.transaction();

      // 1. 存储到 blog
      const blog = {
        title: data.title,
        isPublish: data.isPublish,
        introduction: data.introduction,
        img: data.img,
        createTime: new Date() // 始终更新时间
      };
      if (data.id) {
        // 更新
        await app.model['Blog'].update(blog, {
          where: {
            id: data.id
          },
          transaction
        });
      } else {
        // 创建
        blog.blogContentId = ctx.helper.getId();
        blog.id = ctx.helper.getId();
        await app.model['Blog'].create(
          {
            authId: data.userId,
            ...blog
          },
          {
            transaction
          }
        );
      }

      // 2. 更新标签
      if (data.id) {
        // 更新博客，需要判断标签是否有变化
        let oldTagIdList = await app.model['BlogTag'].findAll({
          attributes: ['tagId'],
          where: {
            blogId: data.id
          },
          raw: true
        });
        if (data.tagIds) {
          if (oldTagIdList && oldTagIdList.length > 0) {
            oldTagIdList = oldTagIdList.map(item => item.tagId);
          }
          const tagIdList = data.tagIds.split(',');
          if (oldTagIdList && oldTagIdList.length > 0) {
            // 需要被移除的标签
            const removeTagIdList = oldTagIdList
              .filter(id => !tagIdList.includes(id));
            if (removeTagIdList.length > 0) {
              await app.model['BlogTag'].destroy(
                {
                  where: {
                    blogId: data.id,
                    tagId: {
                      [opIn]: removeTagIdList
                    }
                  }
                },
                {
                  transaction
                }
              );
            }
          }

          // 需要新增的标签
          let newTagList = tagIdList;
          if (oldTagIdList && oldTagIdList.length > 0) {
            newTagList = newTagList.filter(id => !oldTagIdList.includes(id));
          }
          if (newTagList.length > 0) {
            const newRecords = newTagList.map(tagId => {
              return {
                id: ctx.helper.getId(),
                tagId,
                blogId: data.id
              };
            });
            await app.model['BlogTag'].bulkCreate(newRecords, {
              transaction
            });
          }
        }
      } else {
        // 新增的博客，直接插入
        if (data.tagIds) {
          const newRecords = data.tagIds.split(',').map(tagId => {
            return {
              id: ctx.helper.getId(),
              tagId,
              blogId: blog.id
            };
          });
          await app.model['BlogTag'].bulkCreate(newRecords, {
            transaction
          });
        }
      }

      // 3. 添加/修改 contentMd
      if (data.id) {
        // 修改
        await app.model['BlogContent'].update(
          {
            contentMd: data.contentMd,
            highlight: data.highlight
          },
          {
            where: {
              blogId: data.id
            },
            transaction
          }
        );
      } else {
        // 新增
        await app.model['BlogContent'].create(
          {
            id: blog.blogContentId,
            blogId: blog.id,
            contentMd: data.contentMd,
            highlight: data.highlight
          },
          {
            transaction
          }
        );
      }
      await transaction.commit();
      return data.id || blog.id;
    } catch (e) {
      console.log(e);
      await transaction.rollback();
      throw new Error('保存博客失败');
    }
  }
}

module.exports = BlogService;
