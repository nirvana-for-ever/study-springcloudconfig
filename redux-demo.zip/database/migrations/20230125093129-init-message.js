'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    const { STRING } = Sequelize;
    await queryInterface.createTable('message', {
      id: { type: STRING(30), primaryKey: true },
      content: { type: STRING(255), allowNull: false },
      name: { type: STRING(255), allowNull: false }
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('message');
  }
};
