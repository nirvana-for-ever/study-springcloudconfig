'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.removeColumn('blog', 'tags');
  },

  async down (queryInterface, Sequelize) {
    const { STRING } = Sequelize;
    await queryInterface.addColumn('blog', 'tags', {
      type: STRING(100),
      allowNull: false
    });
  }
};
