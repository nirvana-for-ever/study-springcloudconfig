'use strict';

module.exports = (app) => {
  const { STRING } = app.Sequelize;

  const Message = app.model.define('message', {
    id: { type: STRING(30), primaryKey: true },
    content: { type: STRING(255), allowNull: false },
    name: { type: STRING(255), allowNull: false }
  });

  return Message;
};
