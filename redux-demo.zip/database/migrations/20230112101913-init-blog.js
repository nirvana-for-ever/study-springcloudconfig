'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  /**
   * -- blog_v2.blog definition
   */
  async up(queryInterface, Sequelize) {
    const { DATE, STRING, BIGINT, TINYINT } = Sequelize;
    await queryInterface.createTable('blog', {
      id: { type: STRING(30), primaryKey: true },
      auth_id: { type: STRING(30), allowNull: false },
      blog_content_id: { type: STRING(30), allowNull: false },
      read_count: { type: BIGINT({ unsigned: true }), defaultValue: 0 },
      comment_count: { type: BIGINT({ unsigned: true }), defaultValue: 0 },
      title: { type: STRING(100) },
      create_time: { type: DATE, allowNull: false },
      is_publish: { type: TINYINT, defaultValue: 0 },
      introduction: { type: STRING(100) }
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('blog');
  }
};
