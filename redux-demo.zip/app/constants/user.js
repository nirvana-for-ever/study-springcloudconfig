exports.RSA_PRIVATE_KEY = `-----BEGIN PRIVATE KEY-----
MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAMTEdP07u8ymchB0
Z5V6+dyKsBhFlh3IQ6JsfshhZPzL+DvFpCYFR91S0kyyV/o12QuyxMVWyon4vMdY
+lwyhNU+Gnfpe8m/88ZWdOzL09C4I6rnjcmwLTBoQBUGGzVcVm+CDVgU1y/foKNK
3aCGuyRESI9BuOy6lwFQhND01LJtAgMBAAECgYBqk2IuWzFQGoNDqFkGnPJC4xeY
PfCeNv9zNULCdAZH6o6MiXNsaIXROe/QPPTsAEiMTorHvEe9zW0qqGYKlA5fom8R
nORGGI2Tpci84LU+vvBM1qZj/IHXflhOEL3P1KIKnzzOSbOmCCm2ZIVIiaSPaOeN
l+/QBEeE/1OByYg1IQJBAOwiMRy+E+LH6vW+yeI0OZpVuOdAOd0RRRElaWGVhTFY
J64ZcEoJdmrT+83srG39XLYsCOmk9dPNbviPs7B77cUCQQDVUmcubxgE0xd6nR7t
rPNcuk8Zg5iHtcq6D08OZpJuH1LUzPjQ1yUjXWDRMy4ECQrS/DC6c8gjmBTuHpp6
s+SJAkEAsRGSsnL2hoBTeKPwz2dKKqlNVlubCGMC37CmLT7p+e6ZEryQr3QZEFKV
5/0p7/ClrRWoOUwx6vmJ1Wos3JKR4QJBAI0yrO9UQ262Fp1nMJibWL4w57h4nVZ+
owBCr85VYGkZvKb0QWFidseQwEvYd4XeQlbi7JINnxTITlpK0W+UcRkCQElC52G5
l/8UkCg568pH4QHrIXie7VLfDcZ3lQ0kpf7PwCJjtIQub+ZhwLkNoyVKlyCbGP4C
g/97/UzX3RV9Br0=
-----END PRIVATE KEY-----`;

exports.USER_TOKEN = 'BEAR_ID';

exports.NEED_LOGIN_PATH = [
  '/v2/api/blog/draft/list',
  '/v2/api/tag/list',
  '/v2/api/oss/sts',
  '/v2/api/blog/edit',
  '/v2/api/tag/add',
  '/v2/api/blog/submit',
  '/v2/api/user/update/info',
  '/v2/api/user/logout',
  '/v2/api/user/myinfo'
];

exports.TOP_BLOG_SIZE = 3;

exports.REGISTER_EMAIL_HTML = (code, account) => {
  return `<div style="width: 750px; margin: 0 auto; font-size: 16px">
    <img src="https://img.nirvana1234.xyz/nirvana-v2-logo.png" style="display: block; margin: 0 auto; width: 200px" />
    <div style="margin: 10px 0">你好, </div>
    <div style="margin: 10px 0">为了验证你的账号 ${account}, 请在验证处输入该验证码</div>
    <div style="margin: 30px auto; color: #ec6f5a; font-weight: 600; text-align: center; font-size: 25px">${code}</div>
    <div style="margin: 5px auto">验证码将在5分钟后失效</div>
    <div style="margin: 5px auto">如果你无请求验证码, 可以忽略本邮件</div>
    <div style="margin:10px auto; text-align: right">牛蛙呐博客</div>
  </div>`;
};

exports.DEFAULT_PHOTO = 'https://img.nirvana1234.xyz/ggx2.blob';

exports.REGISTER_REDIS_CODE_KEY_PREFIX = 'register_code_';
