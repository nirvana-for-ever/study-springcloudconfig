export default function BlogPage() {
  return (
    <div>blog</div>
  );
};
