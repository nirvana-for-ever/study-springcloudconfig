'use strict';

module.exports = (app) => {
  const { STRING, BIGINT } = app.Sequelize;

  const Tag = app.model.define('tag', {
    id: { type: STRING(30), primaryKey: true },
    name: { type: STRING(30), allowNull: false },
    description: { type: STRING(100) },
    hot: { type: BIGINT, defaultValue: 0 }
  });

  return Tag;
};
