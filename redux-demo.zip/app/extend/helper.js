'use strict';

const IdWorker = require('../utils/snowflake');

module.exports = {
  // 方法扩展
  getId() {
    return IdWorker.getId();
  }
  // 属性扩展
  // get time() {
  //   return getTime();
  // }
}