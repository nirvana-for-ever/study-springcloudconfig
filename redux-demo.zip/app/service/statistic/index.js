'use strict';

const Service = require('egg').Service;
const { AppError, ERROR_CODE_MAP } = require('../../error');

class StatisticService extends Service {

  /**
   * 获取简单数据信息（封面数据展示，只用 博客数量、博客浏览量、点赞数量）
   */
  async getSimpleInfo() {

    const { Sequelize } = this.app;
    const res = await this.app.model['Blog'].findOne({
      attributes: [
        [Sequelize.fn('COUNT', Sequelize.col('*')), 'blogCount'],
        [Sequelize.fn('SUM', Sequelize.col('read_count')), 'readCount'],
        [Sequelize.fn('SUM', Sequelize.col('like_count')), 'likeCount']
      ],
      raw: true
    });
    console.log(res);
    return res;
  }
}

module.exports = StatisticService;
