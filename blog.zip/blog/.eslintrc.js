module.exports = {
  extends: [
    'alloy',
    'alloy/react',
    'alloy/typescript',
    'plugin:react-hooks/recommonded'
  ],
  plugin: ['prettier'],
  globals: {
    SERVER_BASE_PATH: true
  },
  env: {
    browser: true,
    node: true
  },
  rules: {
    'prettier/prettier': 'error'
  }
};
