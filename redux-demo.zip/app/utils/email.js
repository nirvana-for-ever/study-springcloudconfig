'use strict';
const nodemailer = require('nodemailer');
const { REGISTER_EMAIL_HTML } = require('../constants/user');

// 创建Nodemailer传输器 SMTP 或者 其他 运输机制
const transporter = nodemailer.createTransport({
  host: 'smtp.qq.com', // 第三方邮箱的主机地址
  port: 465,
  secure: true, // true for 465, false for other ports
  auth: {
    user: 'blog4nirvana@qq.com', // 发送方邮箱的账号
    pass: 'wdvftlvthlujdhig' // 邮箱授权密码
  }
});

module.exports.sendRegisterMail = (code, account) => {
  return transporter.sendMail({
    from: '"牛蛙呐博客" <blog4nirvana@qq.com>', // 发送方邮箱的账号
    to: account, // 邮箱接受者的账号
    subject: '牛蛙呐博客注册-邮箱验证', // Subject line
    text: `欢迎注册牛蛙呐博客, 账号: ${account}, 你的邮箱验证码是: ${code}, 请在5分钟内进行验证`, // 文本内容
    html: REGISTER_EMAIL_HTML(code, account) // html 内容, 如果设置了html内容, 将忽略text内容
  });
};
