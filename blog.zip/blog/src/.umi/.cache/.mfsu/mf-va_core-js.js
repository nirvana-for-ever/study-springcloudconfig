import _ from 'E:/BE_HAPPY/Java/VSCodeProject/blog/node_modules/@umijs/preset-built-in/node_modules/core-js';
export default _;
export * from 'E:/BE_HAPPY/Java/VSCodeProject/blog/node_modules/@umijs/preset-built-in/node_modules/core-js';
