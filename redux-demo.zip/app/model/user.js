'use strict';

module.exports = app => {
  const { STRING, DATE, TEXT } = app.Sequelize;

  const User = app.model.define('user', {
    // 自动驼峰转换
    id: { type: STRING(30), primaryKey: true },
    nickName: { type: STRING(30), allowNull: false },
    password: { type: STRING(100), allowNull: false },
    createTime: { type: DATE, allowNull: false },
    // 邮箱或手机号
    account: { type: STRING(100), unique: true },
    photo: { type: TEXT('long'), allowNull: false },
    sign: { type: STRING(100) },
    birth: { type: DATE },
    company: { type: STRING(30) },
    job: { type: STRING(30) },
    status: { type: STRING(30), defaultValue: 'focusing' }
  });

  return User;
};
