安装文档：https://docs.docker.com/engine/install/centos/

步骤：

安装gcc：

```shell
yum -y install gcc-c++
```

卸载旧版本：

```shell
yum remove docker \
                  docker-client \
                  docker-client-latest \
                  docker-common \
                  docker-latest \
                  docker-latest-logrotate \
                  docker-logrotate \
                  docker-engine
```

安装utils软件包

```shell
yum install -y yum-utils device-mapper-persistent-data lvm2
```

安装镜像仓库

```shell
# 这样太卡
yum-config-manager \
    --add-repo \
    https://download.docker.com/linux/centos/docker-ce.repo
# 用aliyun
yum-config-manager --add-repo https://mirrors.aliyun.com/docker-ce/linux/centos/docker-ce.repo
```

更新yum软件包索引

```shell
yum makecache fast
```

安装docker引擎

```shell
yum -y install docker-ce
```

启动docker

```shell
systemctl start docker
```

查看docker状态

```shell
systemctl start docker
```

版本和helloworld

```shell
docker version
docker run hello-world
```

配置镜像加速

```shell
vi /etc/docker/daemon.json
# 文件内容为（自己注册一个阿里云账户，搜索容器镜像服务，点击镜像加速器）：
{
  "registry-mirrors": ["https://jcum1t2v.mirror.aliyuncs.com"]
}
# 修改后重新加载，重新启动
systemctl daemon-reload
systemctl restart docker

#上面那个出了问题，改用下面（出了问题应该是磁盘空间不够）

{
"registry-mirrors": ["https://docker.mirrors.ustc.edu.cn/","https://hub-mirror.c.163.com","https://registry.docker-cn.com"],
"insecure-registries": ["10.0.0.12:5000"]
}
```

卸载

```shell
systemctl stop docker
yum -y remove docker-ce
rm -rf /var/lib/docker
```

