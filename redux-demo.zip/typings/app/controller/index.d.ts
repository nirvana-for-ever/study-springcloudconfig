// This file is created by egg-ts-helper@1.34.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBaseController = require('../../../app/controller/BaseController');
import ExportBlogIndex = require('../../../app/controller/blog/index');
import ExportMessageIndex = require('../../../app/controller/message/index');
import ExportOssIndex = require('../../../app/controller/oss/index');
import ExportStatisticIndex = require('../../../app/controller/statistic/index');
import ExportTagIndex = require('../../../app/controller/tag/index');
import ExportUserIndex = require('../../../app/controller/user/index');

declare module 'egg' {
  interface IController {
    baseController: ExportBaseController;
    blog: {
      index: ExportBlogIndex;
    }
    message: {
      index: ExportMessageIndex;
    }
    oss: {
      index: ExportOssIndex;
    }
    statistic: {
      index: ExportStatisticIndex;
    }
    tag: {
      index: ExportTagIndex;
    }
    user: {
      index: ExportUserIndex;
    }
  }
}
