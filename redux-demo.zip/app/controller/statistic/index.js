'use strict';

const BaseController = require('../BaseController');

class StatisticController extends BaseController {

  /**
   * 获取简单数据信息（封面数据展示，只用 博客数量、博客浏览量、点赞数量）
   */
  async getSimpleInfo() {
    const { ctx } = this;
    const data = await ctx.service.statistic.index.getSimpleInfo();
    this.success({ data });
  }

}

module.exports = StatisticController;
