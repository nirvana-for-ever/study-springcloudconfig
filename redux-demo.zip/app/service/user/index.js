'use strict';

const Service = require('egg').Service;
const { STATUS_PUBLISH } = require('../../constants/blog');
const { USER_TOKEN, DEFAULT_PHOTO, REGISTER_REDIS_CODE_KEY_PREFIX } = require('../../constants/user');
const { AppError, ERROR_CODE_MAP } = require('../../error');
const { randomCode } = require('../../utils');
const { md5, rsaDecrypt, randomUUID } = require('../../utils/auth');
const { sendRegisterMail } = require('../../utils/email');
const { sliceBirthString } = require('../../utils/user');

class UserService extends Service {

  /**
   * 获取简单用户信息
   * 1. 博客详情页查找作者信息
   * 
   * id, nickName, photo, 获赞数量, 发表数量, 阅读数量
   * 前端需要做的：数量为 0 就不展示
   */
  async getUserSimpleInfoById(id) {
    const user = await this.app.model['User'].findByPk(id, {
      attributes: [
        'id',
        'nickName',
        'photo'
      ]
    });

    if (!user) {
      return null;
    }

    const blogInfo = await this.app.model['Blog'].findOne({
      attributes: [
        this.app.Sequelize.literal('count(*) as publishCount'),
        this.app.Sequelize.literal('sum(read_count) as readCount'),
        this.app.Sequelize.literal('sum(like_count) as likeCount')
      ],
      where: {
        authId: id,
        isPublish: STATUS_PUBLISH
      },
      raw: true
    });

    return {
      id: user.id,
      nickName: user.nickName,
      photo: user.photo,
      publishCount: blogInfo?.publishCount || 0,
      readCount: blogInfo?.readCount || 0,
      likeCount: blogInfo?.likeCount || 0
    }
  }

  /**
   * 根据 id 数组获取用户的昵称
   */
  async getUserNicknameListByIds(ids) {
    const { in: opIn } = this.app.Sequelize.Op;
    const users = await this.app.model['User'].findAll({
      attributes: [
        'id',
        'nickName',
      ],
      where: {
        id: {
          [opIn]: ids
        }
      },
      raw: true
    });
    return users;
  }

  /**
   * 登录
   */
  async login({ account, password, rememberMe }) {
    // 解密数据
    const realPassword = rsaDecrypt(password);
    const md5Password = md5(realPassword);

    const user = await this.app.model['User'].findOne({
      where: {
        account
      },
      raw: true
    });

    if (!user || user.password !== md5Password) {
      throw new AppError(ERROR_CODE_MAP.LOGIN_FAILED);
    }

    // 登录成功
    let key = randomUUID();
    let exists = await this.app.redis.exists(key);
    while (exists) {
      key = randomUUID();
      exists = await this.app.redis.exists(key);
    }

    delete user.password;
    // 没有记住我就只保存1天，隔天就算还保持会话也让他失效重新登录
    await this.app.redis.set(key, JSON.stringify(user), 'EX', rememberMe ? 3600 * 24 * 365 : 3600 * 24);

    const options = {
      httpOnly: true,
      signed: false
    };
    if (rememberMe) options.maxAge = 1000 * 3600 * 24 * 365;
    this.ctx.cookies.set(
      USER_TOKEN,
      key,
      options
    );
    
    return {};
  }

  async logout() {
    const token = this.ctx.cookies.get(USER_TOKEN, {
      signed: false
    });
    await this.ctx.app.redis.del(token);
  }

  async getUserInfoById({ id }) {
    const user = await this.app.model['User'].findByPk(id, {
      attributes: [
        'id',
        'nickName',
        'createTime',
        'photo',
        'sign',
        'birth',
        'company',
        'job',
        'status'
      ],
      raw: true
    });
    if (!user) {
      throw new AppError(ERROR_CODE_MAP.USER_NOT_EXITE);
    }
    user.birth = sliceBirthString(user.birth);
    return user;
  }

  async updateInfo(data) {
    const fields = Object.keys(data);
    await this.app.model['User'].update(data, {
      where: {
        id: data.id
      },
      fields
    });

    // 更新 redis 数据
    const user = await this.app.model['User'].findByPk(data.id, {
      attributes: {
        exclude: [
          'password'
        ]
      },
      raw: true
    });
    const token = this.ctx.cookies.get(USER_TOKEN, {
      signed: false
    });
    if (!user || !token) throw Error();
    user.birth = sliceBirthString(user.birth);
    const ttl = await this.ctx.app.redis.ttl(token);
    await this.ctx.app.redis.set(token, JSON.stringify(user), 'EX', ttl);
  }

  /**
   * 检查账号是否已经注册过
   * 返回 true 表示该账号可以注册
   * @param {*} param0 
   */
  async checkAccount({ account }) {
    const count = await this.app.model['User'].count({
      where: {
        account
      },
      raw: true
    });
    return {
      ok: count === 0
    };
  }

  async sendVerify({ account, password, nickName, type }) {
    const { ok } = await this.ctx.service.user.index.checkAccount({ account });
    if (!ok) throw new AppError(ERROR_CODE_MAP.ACCOUNT_ALREADY_IN_USE);

    // 解密数据
    const realPassword = rsaDecrypt(password);
    const md5Password = md5(realPassword);

    const code = randomCode();
    const user = {
      account,
      password: md5Password,
      nickName,
      photo: DEFAULT_PHOTO,
      createTime: new Date()
    };
    const redisKey = `${REGISTER_REDIS_CODE_KEY_PREFIX}${account}`;
    const redisUserStr = await this.app.redis.get(redisKey);
    if (redisUserStr) {
      const redisUser = JSON.parse(redisUserStr);
      if (Date.now() - redisUser.sendTime < 1000 * 60) {
        throw new AppError(ERROR_CODE_MAP.ACCOUNT_ALREADY_IN_USE);
      }
    }
    // 可以发送验证码
    await this.ctx.app.redis.set(redisKey, JSON.stringify({
      user,
      code,
      sendTime: Date.now(),
      verifyTimes: 0
    }), 'EX', 60 * 5);
    if (type === 'email') {
      await sendRegisterMail(code, account);
    } else {
      // 发送手机验证码
    }
  }

  /**
   * 校验验证码
   * @param {*} param0 
   */
  async verifyCode({ code, account }) {
    const redisKey = `${REGISTER_REDIS_CODE_KEY_PREFIX}${account}`;
    const redisUserStr = await this.app.redis.get(redisKey);
    if (!redisUserStr) {
      throw new AppError(ERROR_CODE_MAP.VERIFY_CODE_FAILED);
    }
    const redisUser = JSON.parse(redisUserStr);
    // 验证超过5次直接算失败
    if (redisUser.verifyTimes >= 5) throw new AppError(ERROR_CODE_MAP.VERIFY_CODE_FAILED);
    if (`${redisUser.code}` !== `${code}`) {
      redisUser.verifyTimes += 1;
      const ttl = await this.app.redis.ttl(redisKey);
      await this.app.redis.set(redisKey, JSON.stringify(redisUser), 'EX', ttl);
      throw new AppError(ERROR_CODE_MAP.VERIFY_CODE_FAILED);
    }
    // 验证通过
    await this.app.redis.del(redisKey);
    // 插入数据
    await this.app.model['User'].create({
      ...redisUser.user,
      id: this.ctx.helper.getId()
    });
  }
}

module.exports = UserService;
