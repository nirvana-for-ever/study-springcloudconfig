照着mmap看，这里做补充

docker version

docker info   // 列出更详细的docker安装信息

docker --help

docker images  // 列出本机镜像

docker images -a   // 列出所有镜像（包含中间层，容器内部是一层套一层的，docker images只是列出最外层的信息）

docker images -q  // 只显示镜像id

docker images -aq

docker images --digests  // 显示所有镜像的摘要信息

docker images --notrunc  // 显示所有镜像的全部信息

docker search tomcat  // 去官网上搜索tomcat镜像，结果中：STARS表示点赞数，OFFICIAL表示是否是官方的

docker search tomcat -s 100 // 列出STARS数不少于100的tomcat镜像

docker search tomcat -automated  // 只列出automated类型的镜像

docker pull tomcat   // 拉取最新的tomcat镜像，等价于docker pull tomcat:latest

docker pull tomcat:xxx  // 拉取xxx版本的tomcat镜像

docker rmi -f 镜像名:TAG // 删除某个版本的镜像，不写:TAG表示删最新版，或者直接写镜像id

docker rmi -f ${docker images -aq}  // 删除所有镜像，或者用xargs

docker build -f dockerfile文件路径 -t my/centos .

这个命令就会创建一个镜像，-t后面是自定义的名字，注意最后有个.

##### 容器命令

利用镜像创建并运行交互式容器（相当于前台运行）：

docker run -it 镜像ID或镜像名 // i表示以交互式运行容器，就是运行容器之后还要和容器进行交互，t表示给容器分配一个伪终端，相当于进入容器后可以用命令行操作，两个一般一起用

docker run -it --name 自定义名字 镜像ID或镜像名     // 启动容器，并且自定义名称，如果不自定义，那么系统会随机给名字

查看当前有哪些运行的容器（注意是在容器外写的命令）：

docker ps

docker ps -a  // 列出当前正在运行的，包括历史运行过的

docker ps -l   // 显示上一个创建的容器

docker ps -n x  // 显示最近x个创建的容器

docker ps -ql   // 显示上一个创建的容器的容器id，q表示只显示id

exit  // 退出并关闭容器（注意是在容器内部写的命令）

ctrl+P+Q  // 退出容器，但是不停止（只是退出容器的终端），若想再重新进去交互，则用：docker attach 容器id，或者：docker exec -it 容器id 要执行的命令。详解看下面

docker start 容器id或名  // 启动容器，注意是启动之前已经启动过的容器，下面的停止，重启也是

docker restart 容器id或名

docker stop 容器id或名  // 温柔停止

docker kill 容器id或名   // 强行停止

docker rm -f 容器id或名  // 删除已经停止的容器

docker ps -aq|xargs docker rm  // 删除所有容器

docker run -d 镜像id或名  // 以守护式创建并启动容器（相当于后台运行）

docker logs -f -t --tail x 容器id  // 查看容器日志，-t表示加入时间戳，-f表示持续更新日志信息（也就是如果日志还在打印，那么就会接着显示），--tail x表示显示最后的x条日志

docker top 容器id  // 查看容器内的进程

docker inspect 容器id  // 查看容器内部细节，以json串的形式

docker attach 容器id  // 与正在运行的容器进行交互，进入该容器的终端

docker exec -it 容器id 要执行的命令  // 将命令执行在指定容器的终端上，与上面的区别就是这个命令不会进入容器的终端，相当于在外面操作容器

docker exec -it 容器id /bin/bash  // 打开容器命令行

docker cp 容器id:容器内路径 主机路径   // 将容器内的文件复制到主机上

docker run -it -p 8888:8080 tomcat

docker run -it -P tomcat    // 这两个见docker提交命令那一章

剩下的命令看mmap的小总结



**其他命令**：

docker logs 容器名 // 查看某个容器的日志

