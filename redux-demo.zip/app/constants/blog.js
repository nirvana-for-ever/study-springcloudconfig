'use strict';

module.exports = {
  STATUS_DRAFT: 0,
  STATUS_PUBLISH: 1
}
