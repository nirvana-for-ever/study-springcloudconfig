class AppError extends Error {
  constructor(error) {
    super(error.msg);
    this.code = error.code;
    this.msg = error.msg || '';
  }
}

const ERROR_CODE_MAP = {
  BLOG_NOT_EXIST: { code: 40001, msg: '博客不存在' },
  TAG_NOT_EXIST: { code: 40002, msg: '标签不存在' },
  LOGIN_FAILED: { code: 40003, msg: '账号或密码不正确' },
  NEED_LOGIN: { code: 40004, msg: '请先登录后再进行操作' },
  ACCOUNT_ALREADY_IN_USE: { code: 40005, msg: '账号已被占用, 无法注册' },
  VERIFY_CODE_SEND_TOO_OFTEN: { code: 40006, msg: '验证码发送过于频繁' },
  VERIFY_CODE_FAILED: { code: 40007, msg: '验证码错误或已过期' },
  CREATE_TAG_SAME: { code: 40008, msg: '该标签已存在' },
  USER_NOT_EXITE: { code: 40009, msg: '该用户不存在' }
}

module.exports = {
  AppError,
  ERROR_CODE_MAP
};
