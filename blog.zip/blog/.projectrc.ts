export interface IEnvConfig {
  SERVER_BASE_PATH: string;
  PROSESS_ENV: 'dev' | 'prod';
  PUBLIC_PATH: string;
}

export const env: { [key in string]: IEnvConfig } = {
  dev: {
    SERVER_BASE_PATH: 'http://localhost:5000',
    PROSESS_ENV: 'dev',
    PUBLIC_PATH: '/'
  },
  prod: {
    SERVER_BASE_PATH: '',
    PROSESS_ENV: 'prod',
    PUBLIC_PATH: '/v2/'
  }
}
