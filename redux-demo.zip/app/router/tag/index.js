'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  const subRouter = router.namespace('/v2/api/tag');
  
  subRouter.get('/details', controller.tag.index.details);
  subRouter.get('/blog/list', controller.tag.index.getBlogListByTag);
  subRouter.get('/recommand/list', controller.tag.index.getRecommandTags);
  subRouter.get('/list', controller.tag.index.getTagList);
  subRouter.get('/hot/list', controller.tag.index.getHotTag);
  subRouter.post('/add', controller.tag.index.addTag);
};
