export default [
  {
    path: '/',
    component: '@/layouts/BasicLayout',
    routes: [
      {
        path: '/',
        name: '主页',
        component: '@/pages/main/index'
      },
      {
        path: '/blog',
        name: '博客',
        component: '@/pages/blog/index'
      },
      {
        path: '/record',
        name: '档案',
        component: '@/pages/record/index'
      },
      {
        path: '/tag/:id',
        name: '话题',
        component: '@/pages/tag/index'
      },
      {
        path: '/user',
        name: '个人信息',
        component: '@/pages/user/index'
      },
      {
        component: '@/pages/404'
      }
    ]
  }
];
