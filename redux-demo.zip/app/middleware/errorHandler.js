'use strict';

const { AppError, ERROR_CODE_MAP } = require('../error');

module.exports = (option, app) => {
  return async function (ctx, next) {
    try {
      await next();
    } catch (err) {
      // 所有的异常都在 app 上触发一个 error 事件，框架会记录一条错误日志
      app.emit('error', err, this);
      const status = err.status || 500;
      if (err instanceof AppError) {
        // 自定义错误
        ctx.body = {
          code: err.code || -1,
          data: {},
          message: err.msg,
          success: false
        }
      } else {
        // 生产环境时 500 错误的详细错误内容不返回给客户端，因为可能包含敏感信息
        let error;
        if (app.config.env === 'prod') {
          error = 'Internal Server Error';
        } else {
          error = status === 500 ? 'Internal Server Error' : err.message;
        }
        ctx.body = {
          code: -1,
          data: {},
          message: error,
          success: false
        };
      }
      ctx.status = status;
    }
  };
};
