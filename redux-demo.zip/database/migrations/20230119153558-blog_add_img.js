'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const { TEXT } = Sequelize;
    await queryInterface.addColumn('blog', 'img', {
      type: TEXT('long'),
      allowNull: false
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn('blog', 'img');
  }
};
