// This file is created by egg-ts-helper@1.34.1
// Do not modify this file!!!!!!!!!

import 'egg';
import ExportBlog = require('../../../app/model/blog');
import ExportBlogContent = require('../../../app/model/blog_content');
import ExportBlogTag = require('../../../app/model/blog_tag');
import ExportMessage = require('../../../app/model/message');
import ExportTag = require('../../../app/model/tag');
import ExportUser = require('../../../app/model/user');

declare module 'egg' {
  interface IModel {
    Blog: ReturnType<typeof ExportBlog>;
    BlogContent: ReturnType<typeof ExportBlogContent>;
    BlogTag: ReturnType<typeof ExportBlogTag>;
    Message: ReturnType<typeof ExportMessage>;
    Tag: ReturnType<typeof ExportTag>;
    User: ReturnType<typeof ExportUser>;
  }
}
