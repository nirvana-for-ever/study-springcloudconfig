'use strict';

const Controller = require('egg').Controller;

class BaseController extends Controller {
  success({ status = 200, code = 0, data = {}, message = 'ok' } = {}) {
    this.ctx.status = status;
    this.ctx.body = {
      code,
      data,
      message,
      success: true,
    };
  }
}

module.exports = BaseController;
