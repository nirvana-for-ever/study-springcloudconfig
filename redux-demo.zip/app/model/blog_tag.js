'use strict';

module.exports = (app) => {
  const { STRING } = app.Sequelize;

  const BlogTag = app.model.define('blog_tag', {
    id: { type: STRING(30), primaryKey: true },
    blogId: { type: STRING(30), allowNull: false },
    tagId: { type: STRING(30), allowNull: false }
  });

  return BlogTag;
};
