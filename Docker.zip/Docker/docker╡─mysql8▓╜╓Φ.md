docker run -p 3306:3306 --name mysql -e MYSQL_ROOT_PASSWORD=111111 -d mysql

可以指定-v 容器数据卷，方便修改配置文件



如果需要远程连接，按如下步骤（来自网站https://www.cnblogs.com/ya-qiang/p/9094008.html）

启动之后，进入：

docker exec -it mysql /bin/bash

进入之后：

mysql -uroot -p

连上mysql后：

进入mysql 的databases

use mysql;

select host,user,plugin,authentication_string from user;

看到host为%的那一行，需要将那行的plugin改为自己的密码

ALTER USER 'root'@'%' IDENTIFIED WITH mysql_native_password BY 'newpassword';

之后刷新

flush privileges;

# 其他

修改mysql配置文件需要先安装vi，分别执行下面两步：

apt-get update

apt-get install vim -y

# 配置文件样式

```
# Copyright (c) 2017, Oracle and/or its affiliates. All rights reserved.
#
# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; version 2 of the License.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301 USA

#
# The MySQL  Server configuration file.
#
# For explanations see
# http://dev.mysql.com/doc/mysql/en/server-system-variables.html

[client]
default-character-set=utf8

[mysql]
default-character-set=utf8

[mysqld]
pid-file        = /var/run/mysqld/mysqld.pid
socket          = /var/run/mysqld/mysqld.sock
datadir         = /var/lib/mysql
secure-file-priv= NULL

# Custom config should go here
!includedir /etc/mysql/conf.d/

#自定义配置
...
```

