'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    const { STRING, DATE } = Sequelize;
    await queryInterface.createTable('user', {
      id: { type: STRING(30), primaryKey: true },
      nick_name: { type: STRING(30), allowNull: false },
      password: { type: STRING(30), allowNull: false },
      create_time: { type: DATE, allowNull: false },
      // 邮箱或手机号
      account: { type: STRING(100), unique: true },
      photo: { type: STRING(30), allowNull: false },
      sign: { type: STRING(100) },
      birth: { type: DATE },
      company: { type: STRING(30) },
      job: { type: STRING(30) }
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('user');
  }
};