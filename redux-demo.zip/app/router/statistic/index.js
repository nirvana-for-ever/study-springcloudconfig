'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  const subRouter = router.namespace('/v2/api/statistic');
  
  subRouter.get('/info/simple', controller.statistic.index.getSimpleInfo);
};
