'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up(queryInterface, Sequelize) {
    const { STRING } = Sequelize;
    await queryInterface.createTable('blog_tag', {
      id: { type: STRING(30), primaryKey: true },
      blog_id: { type: STRING(30), allowNull: false },
      tag_id: { type: STRING(30), allowNull: false }
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.dropTable('blog_tag');
  }
};
