'use strict';

const BaseController = require('../BaseController');

class MessageController extends BaseController {

  async submit() {
    const { ctx } = this;
    ctx.validate({
      content: {
        type: 'string',
        max: 50
      },
      name: {
        type: 'string',
        max: 10
      }
    }, ctx.request.body);
    await ctx.service.message.index.submit(ctx.request.body);
    this.success();
  }

  // 获取所有的列表
  async list() {
    const { ctx } = this;
    const data = await ctx.service.message.index.list();
    this.success({ data });
  }

}

module.exports = MessageController;
