// @ts-nocheck
import React from 'react';
import { ApplyPluginsType, dynamic } from 'E:/BE_HAPPY/Java/VSCodeProject/blog/node_modules/@umijs/runtime';
import * as umiExports from './umiExports';
import { plugin } from './plugin';

export function getRoutes() {
  const routes = [
  {
    "path": "/",
    "component": dynamic({ loader: () => import(/* webpackChunkName: 'layouts__BasicLayout' */'@/layouts/BasicLayout')}),
    "routes": [
      {
        "path": "/",
        "name": "主页",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__main__index' */'@/pages/main/index')}),
        "exact": true
      },
      {
        "path": "/blog",
        "name": "博客",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__blog__index' */'@/pages/blog/index')}),
        "exact": true
      },
      {
        "path": "/record",
        "name": "档案",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__record__index' */'@/pages/record/index')}),
        "exact": true
      },
      {
        "path": "/tag/:id",
        "name": "话题",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__tag__index' */'@/pages/tag/index')}),
        "exact": true
      },
      {
        "path": "/user",
        "name": "个人信息",
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__user__index' */'@/pages/user/index')}),
        "exact": true
      },
      {
        "component": dynamic({ loader: () => import(/* webpackChunkName: 'p__404' */'@/pages/404')}),
        "exact": true
      }
    ]
  }
];

  // allow user to extend routes
  plugin.applyPlugins({
    key: 'patchRoutes',
    type: ApplyPluginsType.event,
    args: { routes },
  });

  return routes;
}
