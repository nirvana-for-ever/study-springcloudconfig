'use strict';

module.exports = app => {
  const { STRING, DATE, TINYINT, BIGINT, TEXT } = app.Sequelize;

  const Blog = app.model.define(
    'blog',
    {
      id: { type: STRING(30), primaryKey: true },
      authId: { type: STRING(30), allowNull: false },
      blogContentId: { type: STRING(30), allowNull: false },
      readCount: { type: BIGINT({ unsigned: true }), defaultValue: 0 },
      likeCount: { type: BIGINT({ unsigned: true }), defaultValue: 0 },
      commentCount: { type: BIGINT({ unsigned: true }), defaultValue: 0 },
      title: { type: STRING(100) },
      createTime: { type: DATE, allowNull: false },
      isPublish: { type: TINYINT, defaultValue: 0 },
      introduction: { type: STRING(100) },
      img: { type: TEXT('long'), allowNull: false }
    },
    {
      indexes: [
        {
          fields: ['title', 'introduction'],
          name: 'blog_index',
          type: 'FULLTEXT',
          parser: 'ngram'
        }
      ]
    }
  );

  return Blog;
};
