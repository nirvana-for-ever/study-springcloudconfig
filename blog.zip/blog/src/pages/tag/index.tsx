export default function TagPage(props: any) {
  console.log('propspropspropspropsprops', props);
  return (
    <div>
      tag 参数校验
      {props.location.query.id}
    </div>
  );
};
