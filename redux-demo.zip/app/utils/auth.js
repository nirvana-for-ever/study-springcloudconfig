const NodeRSA = require('node-rsa');
const { RSA_PRIVATE_KEY } = require('../constants/user');
const crypto = require('crypto');

// 固定盐
const salt = 'a8b3e72b-a2df-4076-abd5-6ba9d6f630aa';

const privateKey = new NodeRSA(RSA_PRIVATE_KEY);
privateKey.setOptions({ encryptionScheme: 'pkcs1' });

exports.md5 = text => {
  // 加盐
  const saltPassword = `${text}:${salt}`;
  // 加盐的md5值
  const md5 = crypto.createHash('md5');
  const result = md5.update(saltPassword).digest('hex');
  return result;
};

exports.rsaDecrypt = text => {
  // 解密数据
  try {
    return privateKey.decrypt(text, 'utf-8');
  } catch (e) {
    console.log('rsa 解密失败');
    console.log('错误信息==>');
    throw e;
  }
};

exports.randomUUID = () => crypto.randomUUID();
