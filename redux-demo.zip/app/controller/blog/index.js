'use strict';

const BaseController = require('../BaseController');
const dayjs = require('dayjs');
const { submitValidate } = require('../../validator/blog');
const { STATUS_PUBLISH, STATUS_DRAFT } = require('../../constants/blog');

class BlogController extends BaseController {
  async getBlogById() {
    const { ctx } = this;
    const args = {
      id: ctx.params.id,
      isPublish: ctx.query.isPublish
    };
    ctx.validate(
      {
        id: {
          type: 'string',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        }
      },
      args
    );
    const data = await ctx.service.blog.index.getBlogById(
      ctx.params.id,
      STATUS_PUBLISH,
      false
    );
    this.success({ data });
  }

  async getBlogEditById() {
    const { ctx } = this;
    const args = {
      id: ctx.params.id,
      isPublish: ctx.query.isPublish
    };
    ctx.validate(
      {
        id: {
          type: 'string',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        }
      },
      args
    );
    const data = await ctx.service.blog.index.getBlogById(
      ctx.params.id,
      null,
      true
    );
    this.success({ data });
  }

  /**
   * 有 query 参数就按全文检索分数排序
   * 否则就按时间排序
   */
  async getBlogList() {
    const { ctx } = this;
    ctx.validate(
      {
        query: 'string?',
        page: 'number',
        size: 'number'
      },
      ctx.query
    );

    if (ctx.query.page === 0) {
      ctx.session.blogListTime = dayjs().format('YYYY-MM-DD HH:mm:ss');
    }

    const data = await ctx.service.blog.index.getBlogList({
      ...ctx.query,
      timeLimit: ctx.session.blogListTime
    });

    this.success({ data });
  }

  async getUserBlogList() {
    const { ctx } = this;
    ctx.validate(
      {
        page: 'number',
        size: 'number',
        id: {
          type: 'string',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        }
      },
      ctx.query
    );

    if (ctx.query.page === 0) {
      ctx.session.blogListTime = dayjs().format('YYYY-MM-DD HH:mm:ss');
    }

    const data = await ctx.service.blog.index.getBlogList({
      page: ctx.query.page,
      size: ctx.query.size,
      userId: ctx.query.id,
      timeLimit: ctx.session.blogListTime
    });

    this.success({ data });
  }

  async getDraftBlogList() {
    const { ctx } = this;
    ctx.validate(
      {
        page: 'number',
        size: 'number',
      },
      ctx.query
    );

    if (ctx.query.page === 0) {
      ctx.session.blogListTime = dayjs().format('YYYY-MM-DD HH:mm:ss');
    }

    const data = await ctx.service.blog.index.getBlogList({
      ...ctx.query,
      isPublish: STATUS_DRAFT,
      timeLimit: ctx.session.blogListTime,
      userId: ctx.request.body.__redisUserInfo.id
    });

    this.success({ data });
  }

  /**
   * 获取博客推荐列表，取 6 个浏览量最高的
   */
  async getBlogRecommandList() {
    const { ctx } = this;
    const data = await ctx.service.blog.index.getBlogRecommandList();
    this.success({ data });
  }

  /**
   * 获取档案中的博客，全部查出来
   */
  async getRecordList() {
    const { ctx } = this;
    const data = await ctx.service.blog.index.getRecordList();
    this.success({ data });
  }

  /**
   * 上传博客
   */
  async submit() {
    const { ctx } = this;
    // img 不能为空，前端会直接放一张默认图片做封面
    ctx.validate(
      {
        id: {
          type: 'string?',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        },
        // 标签最多选三个
        tagIds: {
          type: 'string?',
          max: 90,
          format: new RegExp('^\\d+(,\\d+)*$', 'g')
        },
        isPublish: {
          type: 'number',
          max: 1,
          min: 0
        },
        contentMd: 'string?',
        highlight: 'string',
        title: {
          type: 'string',
          max: 100,
          min: 1
        },
        introduction: 'string?',
        img: 'string'
      },
      ctx.request.body
    );
    submitValidate(ctx.request.body);
    const blogId = await ctx.service.blog.index.submit({
      ...ctx.request.body,
      userId: ctx.request.body.__redisUserInfo.id
    });
    this.success({ data: { blogId } });
  }
}

module.exports = BlogController;
