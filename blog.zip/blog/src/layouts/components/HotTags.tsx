import { Spin, Dropdown, MenuProps } from 'antd';
import { DownOutlined } from '@ant-design/icons';
import React, { BaseSyntheticEvent, useEffect, useState } from 'react';
import { history } from 'umi';

interface HotTagsProps {
  onClick: Function
}

const App: React.FC<HotTagsProps> = (props) => {
  const toTag = (e: BaseSyntheticEvent, tagId: string) => {
    e.preventDefault();
    props.onClick();
    setCurrentMenus([tagId])
    history.push(`/tag/${tagId}`);
  };

  const [tags, setTags] = useState<MenuProps['items']>([]);

  const [currentMenus, setCurrentMenus] = useState<Array<string>>([]);

  useEffect(() => {
    // 后端返回标签数据
    const data = [
      { id: '123', name: 'Java' },
      { id: '1234', name: 'JavaScript' },
      { id: '1235', name: 'TypeScript' },
      { id: '1236', name: 'Spring Boot' },
      { id: '1237', name: 'MySQL' }
    ];
    setTags(
      data.map(item => {
        return {
          key: item.id,
          label: <a onClick={e => toTag(e, item.id)}>{item.name}</a>
        };
      })
    );
    history.listen((location, action) => {
      if (!location.pathname.includes('/tag')) {
        setCurrentMenus([])
      }
    });
  }, []);

  return (
    <Dropdown
      menu={{
        items: tags,
        selectable: true,
        selectedKeys: currentMenus
      }}
    >
      <a onClick={e => e.preventDefault()}>
        话题
        <DownOutlined />
      </a>
    </Dropdown>
  );
};

export default App;
