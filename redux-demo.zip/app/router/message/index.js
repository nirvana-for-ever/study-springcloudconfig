'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  const subRouter = router.namespace('/v2/api/message');
  
  subRouter.post('/submit', controller.message.index.submit);
  subRouter.get('/list', controller.message.index.list);
};
