const {
  default: Sts20150401,
  AssumeRoleRequest
} = require('@alicloud/sts20150401');
const { Config } = require('@alicloud/openapi-client');
const { default: Util, RuntimeOptions } = require('@alicloud/tea-util');

const createClient = (accessKeyId, accessKeySecret) => {
  let config = new Config({
    // 必填，您的 AccessKey ID
    accessKeyId: accessKeyId,
    // 必填，您的 AccessKey Secret
    accessKeySecret: accessKeySecret
  });
  // 访问的域名
  config.endpoint = 'sts.cn-shenzhen.aliyuncs.com';
  return new Sts20150401(config);
};

exports.getSts = async () => {
  let client = createClient(
    'LTAI4GA8vK2QsH4Xa3YKBJb3',
    'jUh0MreZsX3atstwxSHrVUSw2rPbHk'
  );
  let assumeRoleRequest = new AssumeRoleRequest({
    roleArn: 'acs:ram::1005594274226107:role/mall-role',
    roleSessionName: 'mall-role',
    durationSeconds: 900
  });
  let runtime = new RuntimeOptions({});
  try {
    // 复制代码运行请自行打印 API 的返回值
    const response = await client.assumeRoleWithOptions(
      assumeRoleRequest,
      runtime
    );
    if (response.statusCode === 200) {
      return {
        accessKeyId: response.body.credentials.accessKeyId,
        accessKeySecret: response.body.credentials.accessKeySecret,
        securityToken: response.body.credentials.securityToken
      }
    }
    throw new Error('获取sts请求失败');
  } catch (error) {
    // 如有需要，请打印 error
    console.log(error);
    Util.assertAsString(error.message);
    throw new Error();
  }
};
