'use strict';

const Service = require('egg').Service;
const { AppError, ERROR_CODE_MAP } = require('../../error');

class BlogContentService extends Service {
  /**
   * 获取博客对应 md 源码
   * 1. 查找博客详情
   * 2. 修改博客
   * @param {*} id 
   * @returns 
   */
  async getMd(id) {
    const content = await this.app.model['BlogContent'].findOne({
      attributes: ['contentMd', 'highlight'],
      where: {
        id
      },
      raw: true
    });

    return content;
  }
}

module.exports = BlogContentService;
