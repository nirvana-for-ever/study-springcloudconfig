'use strict';

const Service = require('egg').Service;
const { AppError, ERROR_CODE_MAP } = require('../../error');

class TagService extends Service {
  /**
   * 获取简单标签信息，获取多个标签信息
   * 1. 博客列表
   * 
   * @param ids 标签 id 数组
   */
  async getTagSimpleInfoByIds(ids) {
    if (!Array.isArray(ids) || ids.length === 0) return null;
    const tags = await this.app.model['Tag'].findAll({
      attributes: ['id', 'name'],
      where: {
        id: ids
      },
      raw: true
    });

    return tags;
  }

  async details({ id, initSize }) {
    const tag = await this.app.model['Tag'].findByPk(id, {
      raw: true
    });
    if (!tag) throw new AppError(ERROR_CODE_MAP.TAG_NOT_EXIST);
    const firstPage = await this.ctx.service.blog.index.getBlogListByTag({
      page: 0,
      size: initSize,
      tagId: id
    });
    return {
      ...tag,
      blogs: firstPage
    };
  }

  async getTagList() {
    const tags = await this.app.model['Tag'].findAll({
      attributes: [
        'id',
        'name'
      ],
      order: [['hot', 'DESC']],
      raw: true
    });
    return tags;
  }

  async addTag({ name, description }) {
    const count = await this.app.model['Tag'].count({
      where: {
        name
      },
      raw: true
    });
    if (count !== 0) {
      throw new AppError(ERROR_CODE_MAP.CREATE_TAG_SAME);
    }
    await this.app.model['Tag'].create({
      id: this.ctx.helper.getId(),
      name,
      description
    });
  }

  async getHotTag(limit) {
    const tags = await this.app.model['Tag'].findAll({
      attributes: [
        'id',
        'name',
        'hot'
      ],
      order: [['hot', 'DESC']],
      offset: 0,
      limit,
      raw: true
    });
    return tags;
  }
}

module.exports = TagService;
