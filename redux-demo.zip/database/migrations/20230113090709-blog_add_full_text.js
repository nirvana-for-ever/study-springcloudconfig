'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  /**
   * -- blog_v2.blog definition
   */
  async up(queryInterface, Sequelize) {
    await queryInterface.addIndex('blog', {
      fields: ['title', 'introduction'],
      name: 'blog_index',
      type: 'FULLTEXT',
      parser: 'ngram'
    });
  },

  async down(queryInterface, Sequelize) {
    await queryInterface.removeIndex('blog', 'blog_index');
  }
};
