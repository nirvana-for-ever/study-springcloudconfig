export default function RecordPage() {
  return (
    <div>record</div>
  );
};
