'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const { BIGINT } = Sequelize;
    await queryInterface.addColumn('blog', 'likeCount', {
      type: BIGINT,
      defaultValue: 0
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn('blog', 'likeCount');
  }
};
