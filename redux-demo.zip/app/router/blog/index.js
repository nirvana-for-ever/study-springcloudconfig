'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  const subRouter = router.namespace('/v2/api/blog');
  
  subRouter.get('/details/:id', controller.blog.index.getBlogById);
  subRouter.get('/edit/:id', controller.blog.index.getBlogEditById);
  subRouter.get('/list', controller.blog.index.getBlogList);
  subRouter.get('/user/list', controller.blog.index.getUserBlogList);
  subRouter.get('/draft/list', controller.blog.index.getDraftBlogList);
  subRouter.get('/recommand/list', controller.blog.index.getBlogRecommandList);
  subRouter.get('/record/list', controller.blog.index.getRecordList);
  subRouter.post('/submit', controller.blog.index.submit);
};
