// @ts-nocheck
import { Plugin } from 'E:/BE_HAPPY/Java/VSCodeProject/blog/node_modules/@umijs/runtime';

const plugin = new Plugin({
  validKeys: ['modifyClientRenderOpts','patchRoutes','rootContainer','render','onRouteChange','__mfsu','getInitialState','initialStateConfig','request',],
});

export { plugin };
