const { USER_TOKEN, NEED_LOGIN_PATH } = require("../constants/user");
const { AppError, ERROR_CODE_MAP } = require("../error");

// 校验用户是否能进入请求
module.exports = options => {
  const includeNeedLogin = (url) => {
    for (let i = 0; i < NEED_LOGIN_PATH.length; i++) {
      if (url.includes(NEED_LOGIN_PATH[i])) return true;
    }
    return false;
  }

  return async (ctx, next) => {
    const end = ctx.request.url.indexOf('?');
    const url = ctx.request.url.slice(0, end === -1 ? ctx.request.url.length : end) || '';
    if (includeNeedLogin(url)) {
      const isGetInfo = url === '/v2/api/user/myinfo';

      const token = ctx.cookies.get(USER_TOKEN, {
        signed: false
      });
      if (!token && !isGetInfo) throw new AppError(ERROR_CODE_MAP.NEED_LOGIN);
      const infoStr = await ctx.app.redis.get(token);
      if (!infoStr && !isGetInfo) {
        throw new AppError(ERROR_CODE_MAP.NEED_LOGIN);
      }
      ctx.request.body.__redisUserInfo = !!infoStr ? JSON.parse(infoStr) : null;
    }
    // 执行下一个中间件
    await next();
  }
}
