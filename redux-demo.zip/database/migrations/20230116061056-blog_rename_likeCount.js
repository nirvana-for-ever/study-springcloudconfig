'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    await queryInterface.renameColumn('blog', 'likeCount', 'like_count');
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.renameColumn('blog', 'like_count', 'likeCount');
  }
};
