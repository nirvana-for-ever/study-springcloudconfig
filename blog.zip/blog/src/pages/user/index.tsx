export default function UserPage() {
  return (
    <div>user</div>
  );
};
