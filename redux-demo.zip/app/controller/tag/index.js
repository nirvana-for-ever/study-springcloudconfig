'use strict';

const BaseController = require('../BaseController');

class TagController extends BaseController {
  async details() {
    const { ctx } = this;
    ctx.validate(
      {
        id: {
          type: 'string',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        },
        initSize: 'number'
      },
      ctx.query
    );

    const data = await ctx.service.tag.index.details(ctx.query);
    this.success({ data });
  }

  /**
   * 查找标签对应博客列表
   */
  async getBlogListByTag() {
    const { ctx } = this;
    ctx.validate(
      {
        page: 'number',
        size: 'number',
        tagId: {
          type: 'string',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        }
      },
      ctx.query
    );
    const data = await ctx.service.blog.index.getBlogListByTag(ctx.query);
    this.success({ data });
  }

  /**
   * 查找推荐标签，20个，热度高的优先
   */
  async getRecommandTags() {
    const { ctx } = this;
    const data = await ctx.service.tag.index.getHotTag(20);
    this.success({ data });
  }

  /**
   * 查询所有标签，目前用于写博客页面
   */
  async getTagList() {
    const { ctx } = this;
    const data = await ctx.service.tag.index.getTagList();
    this.success({ data });
  }

  /**
   * 添加新标签
   */
  async addTag() {
    const { ctx } = this;
    ctx.validate(
      {
        name: {
          type: 'string',
          max: 30,
          min: 1
        },
        description: {
          type: 'string?',
          max: 100
        }
      },
      ctx.request.body
    );
    await ctx.service.tag.index.addTag(ctx.request.body);
    this.success();
  }

  /**
   * 查找最火5个标签
   */
  async getHotTag() {
    const { ctx } = this;
    const data = await ctx.service.tag.index.getHotTag(5);
    this.success({ data });
  }

}

module.exports = TagController;
