'use strict';

const { getSts } = require('../../utils/oss');
const BaseController = require('../BaseController');

class MessageController extends BaseController {

  async sts() {
    const data = await getSts();
    this.success({ data });
  }

}

module.exports = MessageController;
