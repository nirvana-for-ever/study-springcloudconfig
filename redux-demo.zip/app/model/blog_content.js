'use strict';

module.exports = (app) => {
  const { STRING, TEXT } = app.Sequelize;

  const BlogContent = app.model.define('blog_content', {
    id: { type: STRING(30), primaryKey: true },
    blogId: { type: STRING(30), allowNull: false },
    contentMd: { type: TEXT('long') },
    highlight: { type: STRING(100), allowNull: false }
  });

  return BlogContent;
};
