'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const { STRING, BIGINT } = Sequelize;
    await queryInterface.createTable('tag', {
      id: { type: STRING(30), primaryKey: true },
      name: { type: STRING(30), allowNull: false },
      description: { type: STRING(100) },
      hot: { type: BIGINT, defaultValue: 0 }
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.dropTable('tag');
  }
};
