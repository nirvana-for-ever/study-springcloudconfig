import _ from 'E:/BE_HAPPY/Java/VSCodeProject/blog/node_modules/antd/es/result';
export default _;
export * from 'E:/BE_HAPPY/Java/VSCodeProject/blog/node_modules/antd/es/result';
