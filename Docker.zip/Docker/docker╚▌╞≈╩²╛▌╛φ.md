##### 在docker中，想要对容器的数据持久化或者共享容器数据，要用到数据卷

有两种方式添加数据卷

- 直接命令添加

  docker run -it -v 宿主机目录:容器内目录 要启动的容器 /bin/bash

  其中v表示volume（数据卷的意思）

  比如：

  docker run -it -v /abc:/def centos /bin/bash

  这样就会在docker容器的根目录下创建一个def文件夹，在主机根目录下创建一个abc文件夹，两个文件夹是互相同步的，如果在def创建一个a.txt，那么在abc也能看到，如果在abc修改文件a.txt，在def也是可见的

  即使在容器停止运行之后，修改abc文件夹的内容，再次启动容器依旧能看到这些修改

  

  docker run -it -v 宿主机目录:容器内目录:ro 要启动的容器 /bin/bash

  上面这个命令多了个ro，表示readonly，只读

  只读是对于docker容器来说的，只有主机有权修改文件夹的内容

- DockerFile添加

  dockerfile就是描述镜像的代码（有点类似.java和.class，.java是dockerfile，.class是镜像）

  具体的dockerfile语法在后面会讲，这里先大概了解一下

  首先在一个文件夹中创建一个文件，随便取名

  在文件中写上

  FROM centos

  VOLUME ["/abc","/def"]

  CMD echo "finished,--------success1"

  CMD /bin/bash

  大致意思：FROM centos表示在centos镜像的基础上，VOLUME ["/abc","/def"]表示在容器根目录创建abc，def两个数据卷的文件夹，echo表示输出一句话

  之后运行命令：

  docker build -f 刚才创建的文件路径 -t my/centos .

  这个命令就会创建一个镜像，-t后面是自定义的名字，注意最后有个.

  这时候，启动我们自己创建的centos镜像，在centos目录下可以看到abc，def两个文件夹，那这两个文件夹与本机的映射在哪？

  在本机中，输入docker inspect 容器id，会打印出很多json字符串，找到

  "Mounts": [
              {
                  "Type": "volume",
                  "Name": "19b8777471d4f2cf449a6720bc6d6dab32cf598f89facc1ba6035e38155a9d68",
                  "Source": "/var/lib/docker/volumes/19b8777471d4f2cf449a6720bc6d6dab32cf598f89facc1ba6035e38155a9d68/_data",
                  "Destination": "/abc",
                  "Driver": "local",
                  "Mode": "",
                  "RW": true,
                  "Propagation": ""
              },
              {
                  "Type": "volume",
                  "Name": "87be44290b1d15b02a17e2ebc9b44637ee82068cb4901bbe9aff7077a209b105",
                  "Source": "/var/lib/docker/volumes/87be44290b1d15b02a17e2ebc9b44637ee82068cb4901bbe9aff7077a209b105/_data",
                  "Destination": "/def",
                  "Driver": "local",
                  "Mode": "",
                  "RW": true,
                  "Propagation": ""
              }
          ]

  这是描述数据卷映射关系的，source和destination就是本机和容器的映射

  

  **容器间传递共享**

  还是用上面的my/centos，先正常启动一个容器docker1:

  docker run -it --name docker1 my/centos

  再启动docker2和docker3:

  分别以如下方式启动（让他们的数据卷来源于docker1）：

  docker run -it --name docker2 --volume-from docker1 my/centos

  docker run -it --name docker3 --volume-from docker1 my/centos

  这样，在docker1数据卷文件夹中添加数据，docker2和3都可见

  并且，只要还有容器使用这个数据卷，数据卷就会一直有效

  比方说，现在删了docker1，那么docker2和3之间的数据仍是同步的

  

