'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const { STRING } = Sequelize;
    await queryInterface.addColumn('blog_content', 'highlight', {
      type: STRING(100),
      allowNull: false
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn('blog_content', 'highlight');
  }
};
