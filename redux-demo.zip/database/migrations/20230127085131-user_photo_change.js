'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const { TEXT } = Sequelize;
    await queryInterface.changeColumn('user', 'photo', {
      type: TEXT('long'),
      allowNull: false
    });
  },

  async down (queryInterface, Sequelize) {
    const { STRING } = Sequelize;
    await queryInterface.changeColumn('user', 'photo', {
      type: STRING(30),
      allowNull: false
    });
  }
};
