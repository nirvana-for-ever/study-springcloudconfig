'use strict';

const BaseController = require('../BaseController');
const { STATUS_PUBLISH } = require('../../constants/blog');
const { TOP_BLOG_SIZE } = require('../../constants/user');

class UserController extends BaseController {
  async login() {
    const { ctx } = this;
    ctx.validate(
      {
        account: 'accountRule',
        password: 'string',
        rememberMe: 'boolean?'
      },
      ctx.request.body
    );

    const data = await ctx.service.user.index.login(ctx.request.body);
    this.success({ data });
  }

  async info() {
    const { ctx } = this;
    this.success({ data: ctx.request.body.__redisUserInfo });
  }

  async logout() {
    const { ctx } = this;
    await ctx.service.user.index.logout();
    this.success();
  }

  async getTopBlogListByUser() {
    const { ctx } = this;
    ctx.validate(
      {
        id: {
          type: 'string',
          format: new RegExp('^[0-9]+$', 'g'),
          max: 30
        }
      },
      ctx.params
    );
    const data = await ctx.service.blog.index.getBlogList({
      page: 0,
      size: TOP_BLOG_SIZE,
      isPublish: STATUS_PUBLISH,
      userId: ctx.params.id
    });
    this.success({ data });
  }

  async infoById() {
    const { ctx } = this;
    ctx.validate(
      {
        id: 'string'
      },
      ctx.params
    );
    const data = await ctx.service.user.index.getUserInfoById(ctx.params);
    this.success({ data });
  }

  async updateInfo() {
    const { ctx } = this;
    ctx.validate(
      {
        nickName: {
          type: 'string?',
          max: 30
        },
        sign: {
          type: 'string?',
          max: 100
        },
        birth: {
          type: 'date?'
        },
        company: {
          type: 'string?',
          max: 30
        },
        job: {
          type: 'string?',
          max: 30
        },
        photo: {
          type: 'string?'
        },
        status: {
          type: 'string?',
          format: new RegExp('^(focusing|vacation|workingFromHome|sick)$', 'g')
        }
      },
      ctx.request.body
    );
    await ctx.service.user.index.updateInfo({
      ...ctx.request.body,
      id: ctx.request.body.__redisUserInfo.id
    });
    this.success();
  }

  /**
   * 检查账号是否有注册过
   */
  async checkAccount() {
    const { ctx } = this;
    ctx.validate({
      account: 'accountRule'
    }, ctx.request.body);
    const data = await ctx.service.user.index.checkAccount(ctx.request.body);
    this.success({ data });
  }

  /**
   * 发送验证码
   */
  async sendVerify() {
    const { ctx } = this;
    ctx.validate({
      account: 'accountRule',
      type: {
        type: 'string',
        format: new RegExp('^(email|phone)$', 'g')
      },
      nickName: {
        type: 'string',
        max: 30
      },
      password: 'string'
    }, ctx.request.body);
    await ctx.service.user.index.sendVerify(ctx.request.body);
    this.success();
  }

  async verifyCode() {
    const { ctx } = this;
    ctx.validate({
      account: 'accountRule',
      code: {
        type: 'string',
        max: 4,
        min: 4
      }
    }, ctx.request.body);
    await ctx.service.user.index.verifyCode(ctx.request.body);
    this.success();
  }

  /**
   * 获取用户的贡献值
   */
  async getUserContribution() {
    const { ctx } = this;
    ctx.validate({
      id: {
        type: 'string',
        format: new RegExp('^[0-9]+$', 'g'),
        max: 30
      }
    }, ctx.query);
  }
}

module.exports = UserController;
