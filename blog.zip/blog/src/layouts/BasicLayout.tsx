import {
  CaretDownFilled,
  DoubleRightOutlined,
  GithubFilled,
  InfoCircleFilled,
  PlusCircleFilled,
  QuestionCircleFilled,
  SearchOutlined
} from '@ant-design/icons';
import ProCard from '@ant-design/pro-card';
import type { ProSettings } from '@ant-design/pro-layout';
import {
  PageContainer,
  ProLayout,
  SettingDrawer,
  ProLayoutProps,
  ProBreadcrumb
} from '@ant-design/pro-layout';
import { ProProvider } from '@ant-design/pro-provider';
import {
  Avatar,
  Button,
  Divider,
  Popover,
  Input,
  theme,
  Menu,
  MenuProps
} from 'antd';
import {
  HeartOutlined,
  ProjectOutlined,
  TagsOutlined
} from '@ant-design/icons';
import React, { useState } from 'react';
import logo from '../imgs/logo.png';
import styles from './BasicLayout.less';
import { history } from 'umi';
import HotTags from './components/HotTags';

interface BasicLayoutProps extends ProLayoutProps {
  route: ProLayoutProps['route'];
}

const BasicLayout: React.FC<BasicLayoutProps> = props => {
  const { route } = props;

  const [settings, setSetting] = useState<Partial<ProSettings> | undefined>({
    layout: 'top',
    navTheme: 'light'
  });

  const [menus] = useState<MenuProps['items']>([
    {
      label: '首页',
      key: '/',
      icon: <HeartOutlined />
    },
    {
      label: '档案',
      key: '/record',
      icon: <ProjectOutlined />
    },
    {
      label: (
        <HotTags
          onClick={() => setCurrentMenu('/tag')}
        />
      ),
      key: '/tag',
      icon: <TagsOutlined />
    }
  ]);

  const [currentMenu, setCurrentMenu] = useState(
    history.location.pathname || '/'
  );

  return (
    <div>{props.children}</div>
    // <ProLayout
    //   title=""
    //   {...props}
    //   {...settings}
    //   logo={logo}
    //   onMenuHeaderClick={() => history.push('/')}
    //   headerRender={(_, defaultDom) => {
    //     return (
    //       <div className={styles['custom-header']}>
    //         {defaultDom}
    //         <div className={styles['content']}>
    //           <Avatar />
    //         </div>
    //       </div>
    //     );
    //   }}
    //   headerContentRender={() => {
    //     return (
    //       <Menu
    //         onClick={({ key }) => {
    //           if (key === '/tag') return;
    //           setCurrentMenu(key);
    //           history.push(key);
    //         }}
    //         selectedKeys={[currentMenu]}
    //         mode="horizontal"
    //         items={menus}
    //       />
    //     );
    //   }}
    // >
    //   {/* <PageContainer
    //     content=""
    //     title={false}
    //   > */}
    //     {props.children}
    //   {/* </PageContainer> */}
    // </ProLayout>
  );
};

export default BasicLayout;
