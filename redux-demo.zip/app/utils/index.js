'use strict';

exports.randomCode = () => {
  return `${(Math.random() * 10000).toFixed(0)}`;
}
