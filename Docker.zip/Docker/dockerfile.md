### 什么是dockerfile？

dockerfile就是用来构建docker镜像的文件

最基础的docker镜像是**scratch**，每个镜像的底部都来源于**scratch**

创建一个新的镜像就是在原有的镜像上，进行一些其他的操作，其他的操作就体现在dockerfile上，创建好dockerfile，再进行build，就能生成新的镜像

具体dockerfile的语法，例子，看mmap

# Dockerfile Volume的含义

https://blog.csdn.net/fangford/article/details/88873104

VOLUME指令只是起到了声明了容器中的目录作为匿名卷

当Dockerfile用Volume中声明了匿名卷但是run的时候没有使用 -v绑定匿名卷的话那么docker就会在/var/lib/docker/volumes这个目录下创建一个目录来绑定匿名卷

# ADD 的含义

ADD target/*.jar  /app.jar    意思如下：

将运行docker build 的时候，当前宿主机目录下的target目录内的jar包放入容器内部根目录下，重命名为app.jar

