'use strict';

const { STATUS_PUBLISH } = require('../constants/blog');

// 不限制最短，最长限制 100 mb
const checkContentMd = (contentMd) => {
  if (contentMd && contentMd.byteLength() > 1024 * 100) {
    throw new AppError('md 超过 100 KB');
  }
}
const checkIntroduction = (introduction) => {
  if (introduction && introduction.length > 100) {
    throw new Error(`introduction 不合法, value: ${introduction}`);
  }
}
const checkImg = (img) => {
  // img 不能为空，前端会直接放一张默认图片做封面
  if (!img || img.length > 100) {
    throw new Error(`img 不合法, value: ${img}`);
  }
}

exports.submitValidate = args => {
  if (+args.isPublish === STATUS_PUBLISH && (!args.title || !args.contentMd || !args.tagIds || !args.introduction)) {
    throw new Error('要发布的博客参数有误');
  }
  checkContentMd(args.contentMd);
  checkIntroduction(args.introduction);
  checkImg(args.img);
};
