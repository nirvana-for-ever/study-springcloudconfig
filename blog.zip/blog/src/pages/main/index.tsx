export default function MainPage() {
  return (
    <div>main</div>
  );
};
