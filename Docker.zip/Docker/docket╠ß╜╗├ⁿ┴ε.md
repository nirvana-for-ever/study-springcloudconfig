docker的commit：当我们run一个镜像的之后，产生一个容器，我们对这个容器进行了一些修改，想要将该容器弄成一个新的镜像，就要用到commit命令

先运行拉取的tomcat镜像

docker run -it -p 8888:8080 tomcat

这命令的意思是启动tomcat镜像，8888:8080是本机端口与docker端口的映射，即本机上开的是8888，对于docker内部开的是8080，这时候访问localhost:8888就能访问到tomcat主页

访问时会报404，需要先进入docker的终端

只能这么进docker exec -it 666fd1e56260 /bin/bash

然后将tomcat目录下的webapps删除，将webapps.dist改成webapps，之后就能访问得到。注意，这改的只是容器，镜像还是不变的

若用docker run -it -P tomcat（注意是大写的P）运行

则是随机分配端口，随机分配的是本机端口，docker内部的端口是tomcat的默认端口8080

**上一步我们对运行的tomcat进行了一些修改，想要保存为自己的镜像咋办？**

在本机的终端上执行：

docker commit -a "nirvana" -m "newtomcat" 容器id 自定义容器名:自定义版本

其中-a后面的是作者名，-m后面的是描述，类似git

执行完之后，docker images 就能看到自己的tomcat了

# 注意

docker commit不能将挂载目录的内容一并提交，需要先停止容器，将挂载的目录打成tar.gz，再利用Dockerfile创建一个新的镜像