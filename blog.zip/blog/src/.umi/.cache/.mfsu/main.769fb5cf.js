/******/ (function() { // webpackBootstrap
var __webpack_exports__ = {};
/*!****************************************!*\
  !*** ./src/.umi/.cache/.mfsu/index.js ***!
  \****************************************/
"😛"
/******/ })()
;