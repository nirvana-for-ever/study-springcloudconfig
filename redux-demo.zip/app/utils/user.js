exports.sliceBirthString = (origin) => {
  return origin.replace(/(^[0-9]{4}-[0-9]{2}-[0-9]{2}).*/g, '$1');
}
