'use strict';

/** @type {import('sequelize-cli').Migration} */
module.exports = {
  async up (queryInterface, Sequelize) {
    const { STRING } = Sequelize;
    await queryInterface.addColumn('user', 'status', {
      type: STRING(30),
      defaultValue: 'focusing'
    });
  },

  async down (queryInterface, Sequelize) {
    await queryInterface.removeColumn('user', 'status');
  }
};
