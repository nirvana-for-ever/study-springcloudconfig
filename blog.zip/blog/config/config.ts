import { defineConfig } from 'umi';
// @ts-ignore
// import pxToViewPort from 'postcss-px-to-viewport';
import { env } from '../.projectrc';
import routes from './routes';

const envConfig = env[process.env.MODE || 'prod'];
export default defineConfig({
  publicPath: envConfig.PUBLIC_PATH,
  nodeModulesTransform: {
    type: 'none'
  },
  routes,
  fastRefresh: {},
  mfsu: {},
  // extraPostCSSPlugins: [
  //   pxToViewPort({
  //     unitToConvert: 'px',
  //     viewportWidth: 1920,
  //     viewportHeight: 1080, // not now used; TODO: need for different units and math for different properties
  //     unitPrecision: 5,
  //     viewportUnit: 'vw',
  //     fontViewportUnit: 'vw', // vmin is more suitable.
  //     selectorBlackList: [],
  //     propList: ['*'],
  //     minPixelValue: 1,
  //     mediaQuery: false,
  //     replace: true,
  //     landscape: false,
  //     landscapeUnit: 'vw',
  //     landscapeWidth: 568
  //   })
  // ],
  define: {
    ...envConfig
  }
});
