'use strict';

/**
 * @param {Egg.Application} app - egg application
 */
module.exports = app => {
  const { router, controller } = app;
  const subRouter = router.namespace('/v2/api/user');
  
  subRouter.get('/myinfo', controller.user.index.info);
  subRouter.get('/info/:id', controller.user.index.infoById);
  subRouter.get('/list/topBlog/:id', controller.user.index.getTopBlogListByUser);
  subRouter.get('/contribution', controller.user.index.getUserContribution);
  subRouter.post('/login', controller.user.index.login);
  subRouter.post('/logout', controller.user.index.logout);
  subRouter.post('/update/info', controller.user.index.updateInfo);
  subRouter.post('/register/checkAccount', controller.user.index.checkAccount);
  subRouter.post('/register/sendVerify', controller.user.index.sendVerify);
  subRouter.post('/register/verifyCode', controller.user.index.verifyCode);
};
