docker pull rabbitmq:3.8.5-management

其中-management的版本表示有管理图形界面的，可以浏览器访问

docker run -itd --name rabbitmq -p 5672:5672 -p 15672:15672 rabbitmq:3.8.5-management

访问192.168.83.137:15672，默认管理界面用户名密码都是guest

15672是管理界面的端口，5672是数据层的端口

